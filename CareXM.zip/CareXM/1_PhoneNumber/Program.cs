﻿using System;

namespace Q1PhoneNumber
{
    class Program
    {
        static void Main(string[] args)
        {
            PhoneNumber phNo = new PhoneNumber();
            Console.WriteLine(phNo.FormatPhoneNumber("1234567890"));
        }
    }
}
