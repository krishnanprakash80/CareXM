﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Q1PhoneNumber
{
    public class PhoneNumber
    {
        public string FormatPhoneNumber(string phoneNum)
        {
            if (String.IsNullOrEmpty(phoneNum))
                return "Phone Number cannot be empty. Please provide 10 digit Phone number to format.";

            // format numbers to phone string
            double phNum;
            if (phoneNum.Length == 10 && double.TryParse(phoneNum, out phNum))
            { // format when 10 digit number is provided.
                return String.Format("{0:###-###-####}", phNum);
            }
            else
            {
                return "Invalid phone number. Please provide 10 digit phone number to format.";
            }
        }
    }
}
