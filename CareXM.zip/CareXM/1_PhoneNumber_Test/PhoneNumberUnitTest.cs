using Microsoft.VisualStudio.TestTools.UnitTesting;
using Q1PhoneNumber;

namespace PhoneNumber_Test
{
    [TestClass]
    public class PhoneNumberUnitTest
    {
        [TestMethod]
        public void PhoneNumber_Valid_Test()
        {
            PhoneNumber ph = new PhoneNumber();
            Assert.AreEqual(ph.FormatPhoneNumber("8011001000"), "801-100-1000");
        }

        [TestMethod]
        public void PhoneNumber_Empty_Test()
        {
            PhoneNumber ph = new PhoneNumber();
            Assert.AreEqual(ph.FormatPhoneNumber(""), "Phone Number cannot be empty. Please provide 10 digit Phone number to format.");
        }

        [TestMethod]
        public void PhoneNumber_InValid_Test()
        {
            PhoneNumber ph = new PhoneNumber();
            Assert.AreEqual(ph.FormatPhoneNumber("8011000"), "Invalid phone number. Please provide 10 digit phone number to format.");
        }
    }
}
