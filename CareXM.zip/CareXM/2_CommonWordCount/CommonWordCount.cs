﻿using System;
using System.Linq;
using System.IO;
using System.Text.RegularExpressions;
using System.Collections.Generic;

namespace _2_CommonWordCount
{
    class CommonWordCount
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Start the Process..");
            ReadFileAndCountMatchWord("Alice_Out.txt", "CommonWords.txt");
        }

        public static void ReadFileAndCountMatchWord(string outputFileName, string commonWordsfileName)
        {
            // Read the common words
            var obj = new object();
            var commonWords = GetCommonWords(commonWordsfileName);

            var text = File.ReadAllText("Alice.txt");

            var match = Regex.Match(text, "\\w+");
            Dictionary<string, int> freq = new Dictionary<string, int>();
            while (match.Success)
            {
                string word = match.Value;
                if (freq.ContainsKey(word))
                {
                    freq[word]++;
                }
                else
                {
                    freq.Add(word, 1);
                }

                match = match.NextMatch();
            }

            foreach(var word in commonWords)
            {
                freq.Remove(word);
            }

            //Write to a file.
            writeToFile(outputFileName, freq);
        }

        private static IList<string> GetCommonWords(string commonWords)
        {
            // Read the common words
            IList<string> commands = new List<string>();

            if (!File.Exists(commonWords))
            {
                Console.WriteLine("File not found");
                return null;
            }

            foreach (var line in File.ReadLines(commonWords))
            {
                if (!String.IsNullOrEmpty(line))
                {
                    commands.Add(line);
                }
            }
            return commands;
        }

        public static void writeToFile(string writeFilename, Dictionary<string, int> freq)
        {
            //Write to a file
            using (System.IO.StreamWriter file = new System.IO.StreamWriter(writeFilename))
            {
                foreach (var elem in freq.OrderByDescending(a => a.Value))
                {
                    file.WriteLine("{0, -12}                {1, -10}", elem.Key, elem.Value);
                }
            }
            Console.WriteLine("Process Completed.");
        }
    }
}
