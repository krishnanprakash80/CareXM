﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _3_ClassDiagram
{
    public class User
    {
        public int id;
        public string firstName;
        public string lastName;
        public string emailAddress;
        public bool isEnabled;
    }
}