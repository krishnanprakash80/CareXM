﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _3_ClassDiagram
{
    public class Admin : User
    {
        public int adminId
        {
            get => default;
            set
            {
            }
        }

        public void disableUser()
        {
            throw new System.NotImplementedException();
        }

        public void enableUser()
        {
            throw new System.NotImplementedException();
        }
    }
}