﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _3_ClassDiagram
{
    public class Nurse : User
    {
        public int supervisorId
        {
            get => default;
            set
            {
            }
        }
    }
}